This is a modified version of CMVS/PMVS.

Authors : 
[Original code author]  Yasutaka Furukawa http://www.cs.washington.edu/homes/furukawa/

[Initial Cmake multiplatform port ]	Pierre moulon pmoulon[AT]gmail.com

--------------------
- Web ressources : - 
--------------------
[CMVS/PMVS] http://http://grail.cs.washington.edu/software/cmvs/
[CMake version] http://opensourcephotogrammetry.blogspot.com/ https://github.com/pmoulon/CMVS-PMVS